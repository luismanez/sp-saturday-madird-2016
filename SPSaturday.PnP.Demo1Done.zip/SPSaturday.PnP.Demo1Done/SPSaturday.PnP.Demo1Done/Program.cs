﻿using Microsoft.SharePoint.Client;
using OfficeDevPnP.Core;
using SPSaturday.PnP.Demo1Done.Extensions;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SPSaturday.PnP.Demo1Done
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Stopwatch stopwatch = Stopwatch.StartNew();

                string url = "https://tenant.sharepoint.com/sites/spsdemo1";

                //get ClientContext
                AuthenticationManager authManager = new AuthenticationManager();
                ClientContext context = 
                    authManager.GetSharePointOnlineAuthenticatedContextTenant(
                        url, StringExtensions.GetUser(), StringExtensions.GetPassword());

                //create List
                var list = context.Web.CreateList(ListTemplateType.GenericList, "PnPList", false);

                //Create View and add it to List
                var view = list.CreateView("PnP View", ViewType.Html, new string[] { "Title", "Modified" }, 10, true);

                //Add Property Bag
                context.Web.SetPropertyBagValue("LmlDemo", "ChangeThis");

                //How to Add an Indexed PropertyBag??
                context.Web.AddIndexedPropertyBagKey("LmlDemo");

                stopwatch.Stop();
                Console.WriteLine("Operation Done. Elapsed: {0}", stopwatch.Elapsed);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }

            Console.WriteLine("Press any key to exit...");
            Console.ReadLine();
        }

        #region SP Stuff NO PnP
        static void DemoNoPnP()
        {
            string url = "https://tenant.sharepoint.com/sites/demo";

            //get ClientContext
            ClientContext context = new ClientContext(url);
            context.Credentials =
                new SharePointOnlineCredentials(
                    StringExtensions.GetUser(),
                    StringExtensions.GetPassword().ToSecureString());

            //create List
            var list = context.Web.Lists.Add(new ListCreationInformation()
            {
                Title = "DemoNoPnP",
                Description = "Created from just CSOM",
                Url = "Lists/DemoNoPnP",
                TemplateType = (int)ListTemplateType.GenericList,
                TemplateFeatureId = new Guid("00BFEA71-DE22-43B2-A848-C05709900100")
            });

            context.Load(list);
            context.ExecuteQuery();

            //Create View and add it to List
            ViewCreationInformation vci = new ViewCreationInformation()
            {
                Title = "NoPnP View",
                ViewTypeKind = ViewType.Html,
                RowLimit = 10,
                ViewFields = new string[] { "Title", "Modified" },
                PersonalView = false,
                SetAsDefaultView = true,
                Paged = false
            };

            var view = list.Views.Add(vci);
            context.Load(view);
            context.ExecuteQuery();

            //Add Property Bag
            var properties = context.Web.AllProperties;
            context.Load(properties);
            context.ExecuteQuery();
            properties["LmlDemo"] = "ChangeThis";
            context.Web.Update();
            context.ExecuteQuery();

            //How to Add an Indexed PropertyBag??
        }
        #endregion
    }
}
