﻿using Microsoft.SharePoint.Client;
using OfficeDevPnP.Core.Framework.Provisioning.ObjectHandlers.TokenDefinitions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SPSaturday.PnP.Demo2Done.PnPExtensibility
{
    public class SiteBaseTemplateToken : TokenDefinition
    {
        public SiteBaseTemplateToken(Web web) : base(web, "~sitebasetemplate", "{sitebasetemplate}")
        {
        }

        public override string GetReplaceValue()
        {
            if (this.CacheValue == null)
            {
                Web.EnsureProperties(w => w.WebTemplate, w => w.Configuration);
                var templateName = string.Format("{0}#{1}", Web.WebTemplate, Web.Configuration); //i.e: ENTWIKI#0
                CacheValue = templateName;
            }

            return CacheValue;
        }
    }
}
