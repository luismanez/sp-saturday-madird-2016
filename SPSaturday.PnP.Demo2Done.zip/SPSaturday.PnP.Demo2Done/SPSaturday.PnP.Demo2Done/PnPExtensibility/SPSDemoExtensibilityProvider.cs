﻿using OfficeDevPnP.Core.Framework.Provisioning.Extensibility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.SharePoint.Client;
using OfficeDevPnP.Core.Diagnostics;
using OfficeDevPnP.Core.Framework.Provisioning.Model;
using OfficeDevPnP.Core.Framework.Provisioning.ObjectHandlers;
using OfficeDevPnP.Core.Framework.Provisioning.ObjectHandlers.TokenDefinitions;

namespace SPSaturday.PnP.Demo2Done.PnPExtensibility
{
    public class SPSDemoExtensibilityProvider : IProvisioningExtensibilityHandler
    {
        public ProvisioningTemplate Extract(ClientContext ctx, ProvisioningTemplate template, ProvisioningTemplateCreationInformation creationInformation, PnPMonitoredScope scope, string configurationData)
        {
            return template;
        }

        public IEnumerable<TokenDefinition> GetTokens(ClientContext ctx, ProvisioningTemplate template, string configurationData)
        {
            return new List<TokenDefinition> { new SiteBaseTemplateToken(ctx.Web) };
        }

        public void Provision(ClientContext ctx, 
            ProvisioningTemplate template,
            ProvisioningTemplateApplyingInformation applyingInformation, 
            TokenParser tokenParser,
            PnPMonitoredScope scope, 
            string configurationData)
        {
            Console.WriteLine(configurationData);
        }
    }
}
