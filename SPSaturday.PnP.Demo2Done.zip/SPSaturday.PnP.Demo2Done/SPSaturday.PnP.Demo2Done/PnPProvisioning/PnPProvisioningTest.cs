﻿using Microsoft.SharePoint.Client;
using OfficeDevPnP.Core;
using OfficeDevPnP.Core.Framework.Provisioning.Connectors;
using OfficeDevPnP.Core.Framework.Provisioning.ObjectHandlers;
using OfficeDevPnP.Core.Framework.Provisioning.Providers.Xml;
using SPSaturday.PnP.Demo2Done.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SPSaturday.PnP.Demo2Done.PnPProvisioning
{
    public static class PnPProvisioningTest
    {
        public static void ExportTemplateTest()
        {
            string url = "https://tenant.sharepoint.com/sites/demo";

            //get ClientContext
            AuthenticationManager authManager = new AuthenticationManager();
            ClientContext context =
                authManager.GetSharePointOnlineAuthenticatedContextTenant(
                    url, StringExtensions.GetUser(), StringExtensions.GetPassword());

            //Note: Enable PublishingWeb feature first: 
            //  Enable-SPOFeature -Identity 94c94ca6-b32f-4da9-a9e3-1f3d343d7ecb
            ProvisioningTemplateCreationInformation ptci = new ProvisioningTemplateCreationInformation(context.Web);
            ptci.FileConnector = new FileSystemConnector(@"c:\SPSaturday", "");
            ptci.IncludeAllTermGroups = true;
            ptci.PersistBrandingFiles = true; //Extract Welcome Page content and Themes
            ptci.HandlersToProcess = 
                OfficeDevPnP.Core.Framework.Provisioning.Model.Handlers.All;

            var template = context.Web.GetProvisioningTemplate(ptci);

            XMLFileSystemTemplateProvider provider = new XMLFileSystemTemplateProvider(@"c:\SPSaturday", "");
            string templateName = "SPSPnPDemo02.xml";
            provider.SaveAs(template, templateName);
        }

        public static void ApplyTemplateTest()
        {
            string url = "https://tenant.sharepoint.com/sites/kk";

            //get ClientContext
            AuthenticationManager authManager = new AuthenticationManager();
            ClientContext context =
                authManager.GetSharePointOnlineAuthenticatedContextTenant(
                    url, StringExtensions.GetUser(), StringExtensions.GetPassword());

            //Load template from XMLFileSystemTemplateProvider
            XMLFileSystemTemplateProvider provider = new XMLFileSystemTemplateProvider(@"c:\SPSaturday", "");
            var template = provider.GetTemplate("SPSPnPDemo02.xml");
            template.Connector = new FileSystemConnector(@"c:\SPSaturday", "");

            //Aplying options ProvisioningTemplateApplyingInformation
            ProvisioningTemplateApplyingInformation ptai = new ProvisioningTemplateApplyingInformation();
            ptai.HandlersToProcess = OfficeDevPnP.Core.Framework.Provisioning.Model.Handlers.All;
            ptai.ProgressDelegate += ShowProgress;
            ptai.MessagesDelegate += ShowMessage;
            ptai.OverwriteSystemPropertyBagValues = false;

            //Apply template
            context.Web.ApplyProvisioningTemplate(template, ptai);
        }

        public static void ApplyTemplateWithCustomExtensibilityProvider()
        {
            string url = "https://tenant.sharepoint.com/sites/kk";
            AuthenticationManager authManager = new AuthenticationManager();
            ClientContext context =
                authManager.GetSharePointOnlineAuthenticatedContextTenant(
                    url, StringExtensions.GetUser(), StringExtensions.GetPassword());

            XMLFileSystemTemplateProvider provider = 
                new XMLFileSystemTemplateProvider(@"C:\_Community\SPSaturday\SPSaturday.PnP.Demo2Done\SPSaturday.PnP.Demo2Done\PnPExtensibility", "");
            var template = provider.GetTemplate("PnPExtensibilityDemo.xml");

            ProvisioningTemplateApplyingInformation ptai = new ProvisioningTemplateApplyingInformation();
            ptai.ProgressDelegate += ShowProgress;
            ptai.MessagesDelegate += ShowMessage;
            ptai.HandlersToProcess =
                OfficeDevPnP.Core.Framework.Provisioning.Model.Handlers.PropertyBagEntries |
                OfficeDevPnP.Core.Framework.Provisioning.Model.Handlers.ExtensibilityProviders;

            context.Web.ApplyProvisioningTemplate(template, ptai);
        }

        static void ShowProgress(string message, int step, int total)
        {
            Console.WriteLine("PROGRESS: {0}. Step: {1} / {2}", message, step, total);
        }

        static void ShowMessage(string message, ProvisioningMessageType messageType)
        {
            Console.WriteLine("MSG: {0}. Type: {1}", message, messageType.ToString());
        }
    }
}
