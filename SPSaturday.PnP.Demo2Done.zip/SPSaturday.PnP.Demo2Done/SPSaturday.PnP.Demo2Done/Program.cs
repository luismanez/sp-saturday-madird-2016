﻿using SPSaturday.PnP.Demo2Done.PnPProvisioning;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SPSaturday.PnP.Demo2Done
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Stopwatch stopwatch = Stopwatch.StartNew();

                PnPProvisioningTest.ExportTemplateTest();

                //PnPProvisioningTest.ApplyTemplateTest();

                //PnPProvisioningTest.ApplyTemplateWithCustomExtensibilityProvider();

                stopwatch.Stop();
                Console.WriteLine("Operation Done. Elapsed: {0}", stopwatch.Elapsed);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }

            Console.WriteLine("Press any key to continue...");
            Console.ReadLine();
        }
    }
}
